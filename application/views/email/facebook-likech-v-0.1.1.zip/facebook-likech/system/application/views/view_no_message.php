<script type="text/javascript">
$(document).ready(function() {
    $("#newmessage").html('');
});
</script>