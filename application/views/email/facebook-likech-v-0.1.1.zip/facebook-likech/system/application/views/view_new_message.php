<script type="text/javascript">
$(document).ready(function() {
    $("#newmessage").html('<img src="<?php echo MAINSITE_URL;?>img/spacer.gif" width="5" height="17" /><img src="<?php echo MAINSITE_URL;?>img/envelope.gif" />');
});
</script>